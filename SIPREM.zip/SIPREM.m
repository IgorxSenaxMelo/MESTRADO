% =========================================================
% fuzzy_promethee_SIPREM_geldermann_comparativo.m
% SIPREM = FAHP trapezoidal individual por especialista
%          + Fuzzy PROMETHEE II individual
%          + agregação posterior dos fluxos líquidos fuzzy
%
% REPRESENTAÇÃO DOS NÚMEROS FUZZY:
% Trapézios armazenados no formato [a b c d], onde:
%   a = suporte inferior
%   b = núcleo inferior
%   c = núcleo superior
%   d = suporte superior
% =========================================================

clear; clc; close all;

%% =========================================================
% CONFIGURAÇÃO AUTOMÁTICA DAS FIGURAS
%% =========================================================

% Identificador único para cada execução
identificador_execucao = datestr(now,'yyyy-mm-dd_HH-MM-SS');

% Pasta específica desta execução
pasta_figuras = fullfile( ...
    pwd, ...
    ['Figuras_' identificador_execucao]);

if ~exist(pasta_figuras,'dir')
    mkdir(pasta_figuras);
end

% Todas as figuras ficam ocultas por padrão.
% Apenas as três figuras principais serão mostradas.
set(groot,'defaultFigureVisible','off');

fprintf('\nPasta das figuras desta execução:\n%s\n',pasta_figuras);
%% ---------------------------------------------------------
% 1. CONFIGURAÇÕES GERAIS
% ---------------------------------------------------------
input_file = 'dados_requisitos_lista.xlsx';
all_sheets = sheetnames(input_file);
all_sheets = all_sheets(1:end-1); % IGNORA ÚLTIMA
nExperts = numel(all_sheets);

nCrit = 5;

% Máximo de requisitos por página nos gráficos longos
req_por_pagina = 40;
crit_names = {'Impacto', 'Custo', 'CAPACIDADE NACIONAL DE IMPLEMENTAÇÃO', 'Prazo', 'RiscoVerif'};

% Direção dos critérios: +1 = maximizar, -1 = minimizar
critDir = [1, -1, 1, -1, -1];

% Funções de preferência: 1 = Usual, 4 = Level
pref_types = [1, 4, 4, 4, 4];
%pref_types = [5, 5, 5, 5, 5];

% Limites das escalas
% Impacto 1-7, Custo 1-7, Capacidade Técnica Nacional para Implementação
% 1-7, Prazo 1-7, Risco Verif 1-7
scale_max = [7, 7, 7, 7, 7];
scale_min = [1, 1, 1, 1, 1];

% amplitude das escalas
A_scale = scale_max - scale_min;

% limiares automáticos
q_vals = [0, 0.06*A_scale(2), 0.06*A_scale(3), 0.06*A_scale(4), 0.06*A_scale(5)];
p_vals = [0, 0.21*A_scale(2), 0.21*A_scale(3), 0.21*A_scale(4), 0.21*A_scale(5)];



% Tabelas trapezoidais para fuzzificação das avaliações
TFN_eval_5 = [
    1.0  1.0  1.5  2.0
    1.5  2.0  2.0  2.5
    2.0  2.5  3.0  3.5
    3.0  3.5  4.0  4.5
    4.0  4.5  5.0  5.0
];

TFN_eval_7 = [
    1.0  1.0  1.5  2.0
    1.0  1.5  2.5  3.0
    2.0  2.5  3.5  4.0
    3.0  3.5  4.5  5.0
    4.0  4.5  5.5  6.0
    5.0  5.5  6.5  7.0
    6.0  6.5  7.0  7.0
];

TFN_eval_9 = [
    1.0  1.0  1.5  2.0
    1.0  1.5  2.5  3.0
    2.0  2.5  3.5  4.0
    3.0  3.5  4.5  5.0
    4.0  4.5  5.0  5.5
    5.0  5.5  6.5  7.0
    6.0  6.5  7.5  8.0
    7.0  7.5  8.5  9.0
    8.0  8.5  9.0  9.0
];


%% ---------------------------------------------------------
% 2. PESOS FUZZY CALCULADOS AUTOMATICAMENTE VIA FAHP
% ---------------------------------------------------------

% SIPREM = pesos dos especialistas do estudo de caso
[w_fuzzy_group, w_group_defuzz, info_SIPREM] = get_pesos_fahp_express('F_AHP_A.xlsx');

if info_SIPREM.num_especialistas ~= nExperts
    error(['Número de especialistas diferente entre F_AHP_A.xlsx (%d) e ', ...
           '%s (%d). Confira as abas.'], ...
           info_SIPREM.num_especialistas, input_file, nExperts);
end

disp('====================================================');
disp('Pesos fuzzy do grupo (FAHP trapezoidal) - calculados automaticamente');
for k = 1:nCrit
    fprintf('%-12s : [%.4f %.4f %.4f %.4f]\n', ...
        crit_names{k}, w_fuzzy_group(k,1), w_fuzzy_group(k,2), ...
        w_fuzzy_group(k,3), w_fuzzy_group(k,4));
end
disp(' ');
disp('Pesos defuzzificados do grupo:');
for k = 1:nCrit
    fprintf('%-12s : %.4f\n', crit_names{k}, w_group_defuzz(k));
end
disp(' ');
disp('====================================================');


%% ---------------------------------------------------------
% 4. LEITURA DAS AVALIAÇÕES DOS REQUISITOS
% ---------------------------------------------------------
T0 = readtable(input_file, 'Sheet', all_sheets{1}, 'VariableNamingRule', 'preserve');
IDs = T0{:,1};
data0 = T0{:,3:(2+nCrit)};
[nReq, ~] = size(data0);

req_labels = arrayfun(@(x) sprintf('R%d', x), 1:nReq, 'UniformOutput', false);


%% ---------------------------------------------------------
% 4A. MATRIZES DE AVALIAÇÃO DOS ESPECIALISTAS + DISPERSÃO
% ---------------------------------------------------------
data_all = zeros(nReq, nCrit, nExperts);
impacto_ind = zeros(nReq, nExperts);

for e = 1:nExperts
    Te = readtable(input_file, 'Sheet', all_sheets{e}, 'VariableNamingRule', 'preserve');
    data_raw = Te{:,3:(2+nCrit)};

data_e = zeros(size(data_raw));

for i = 1:size(data_raw,1)
    for k = 1:size(data_raw,2)
        data_e(i,k) = linguistic2num(data_raw{i,k});
    end
end
    data_all(:,:,e) = data_e;
    impacto_ind(:,e) = data_e(:,1);   % coluna 1 = Impacto
end


%% ---------------------------------------------------------
% 5. AGREGAÇÃO FUZZY DAS AVALIAÇÕES DOS ESPECIALISTAS
% ---------------------------------------------------------

F = zeros(nReq,nCrit,4);

for e = 1:nExperts

    Te = readtable(input_file,...
                   'Sheet',all_sheets{e},...
                   'VariableNamingRule','preserve');

    data_raw = Te{:,3:(2+nCrit)};

    data_e = zeros(size(data_raw));

    for i = 1:size(data_raw,1)
        for k = 1:size(data_raw,2)

            data_e(i,k) = linguistic2num(data_raw{i,k});

        end
    end

    for i = 1:nReq

        for k = 1:nCrit

            val = data_e(i,k);

            trap = fuzzifyByScale( ...
                val,...
                scale_max(k),...
                TFN_eval_5,...
                TFN_eval_7,...
                TFN_eval_9);

            F(i,k,:) = squeeze(F(i,k,:))' + trap;

        end
    end
end

F = F / nExperts;
%% ---------------------------------------------------------
% 7. SIPREM - PROMETHEE individual por especialista + agregação posterior
% ---------------------------------------------------------
rank_matrix = zeros(nReq, nExperts + 1);
col_names = [all_sheets(:); {'Grupo SIPREM'}];

phi_net_experts       = zeros(nReq, nExperts);
Phi_plus_experts      = zeros(nReq, nExperts);
Phi_minus_experts     = zeros(nReq, nExperts);

Phi_plus_fuzzy_exp    = zeros(nReq, 4, nExperts);
Phi_minus_fuzzy_exp   = zeros(nReq, 4, nExperts);
Phi_net_fuzzy_exp     = zeros(nReq, 4, nExperts);

for e = 1:nExperts
    Te = readtable(input_file, 'Sheet', all_sheets{e}, 'VariableNamingRule', 'preserve');
    data_raw = Te{:,3:(2+nCrit)};

data_e = zeros(size(data_raw));

for i = 1:size(data_raw,1)
    for k = 1:size(data_raw,2)
        data_e(i,k) = linguistic2num(data_raw{i,k});
    end
end

    % fuzzificação das avaliações do especialista
    F_e = zeros(nReq, nCrit, 4);
    for i = 1:nReq
        for k = 1:nCrit
            val = data_e(i,k);

            trap = fuzzifyByScale(val, scale_max(k), TFN_eval_5, TFN_eval_7, TFN_eval_9);
        F_e(i,k,:) = trap;
        end
    end

    % pesos fuzzy individuais vindos da função FAHP
w_fuzzy_e = squeeze(info_SIPREM.w_fuzzy_individual(:,:,e));

    % fuzzy PROMETHEE II individual
    [phi_plus_e, phi_minus_e, phi_net_e, phi_plus_fz_e, phi_minus_fz_e, phi_net_fz_e] = ...
        runFuzzyPrometheeTrap(F_e, w_fuzzy_e, critDir, pref_types, q_vals, p_vals);

    Phi_plus_experts(:,e)    = phi_plus_e;
    Phi_minus_experts(:,e)   = phi_minus_e;
    phi_net_experts(:,e)     = phi_net_e;

    Phi_plus_fuzzy_exp(:,:,e)  = phi_plus_fz_e;
    Phi_minus_fuzzy_exp(:,:,e) = phi_minus_fz_e;
    Phi_net_fuzzy_exp(:,:,e)   = phi_net_fz_e;

    rank_matrix(:,e) = nReq + 1 - tiedrank(phi_net_e);
end

% agregação posterior dos fluxos fuzzy individuais
Phi_plus_fuzzy  = zeros(nReq, 4);
Phi_minus_fuzzy = zeros(nReq, 4);
Phi_net_fuzzy   = zeros(nReq, 4);

Phi_plus  = zeros(nReq,1);
Phi_minus = zeros(nReq,1);
phi_net   = zeros(nReq,1);

for i = 1:nReq
    accP = [0 0 0 0];
    accM = [0 0 0 0];
    accN = [0 0 0 0];

    for e = 1:nExperts
        accP = trap_add(accP, squeeze(Phi_plus_fuzzy_exp(i,:,e))');
        accM = trap_add(accM, squeeze(Phi_minus_fuzzy_exp(i,:,e))');
        accN = trap_add(accN, squeeze(Phi_net_fuzzy_exp(i,:,e))');
    end

    Phi_plus_fuzzy(i,:)  = trap_scalar_div(accP, nExperts);
    Phi_minus_fuzzy(i,:) = trap_scalar_div(accM, nExperts);
    Phi_net_fuzzy(i,:)   = trap_scalar_div(accN, nExperts);

    Phi_plus(i)  = defuzz_coa(Phi_plus_fuzzy(i,:));
    Phi_minus(i) = defuzz_coa(Phi_minus_fuzzy(i,:));
    phi_net(i)   = defuzz_coa(Phi_net_fuzzy(i,:));
end

rank_matrix(:,end) = nReq + 1 - tiedrank(phi_net);

[~, ord_rows] = sort(rank_matrix(:,end), 'ascend');
rank_matrix_ord = rank_matrix(ord_rows,:);
req_labels_ord = req_labels(ord_rows);


% =========================================================
% DEFINIÇÃO DE KEY POR MAIORIA
% =========================================================

impacto_max = impacto_ind == scale_max(1);

candidatos_key = find( ...
    sum(impacto_max,2)/nExperts >= 0.5 );
% =========================================================
% ALERTA DE DIVERGÊNCIA ENTRE ESPECIALISTAS
% =========================================================

impacto_max_val = max(impacto_ind, [], 2);
impacto_min_val = min(impacto_ind, [], 2);

alerta_div = (impacto_max_val - impacto_min_val) >= 3;

% classificação SIPREM (grupo) via K-means
[cat, idx_km_SIPREM, C_SIPREM, group_names_SIPREM] = ...
    classify_requirements_kmeans(phi_net, candidatos_key);


T_kmeans_SIPREM = table((1:numel(C_SIPREM))', C_SIPREM(:), group_names_SIPREM(:), ...
    'VariableNames', {'Cluster','Centroide','Grupo'});

disp(' ');
disp('--- CENTRÓIDES K-MEANS (SIPREM) ---');
disp(T_kmeans_SIPREM);


%% ---------------------------------------------------------
% 9. TABELA FINAL E EXPORTAÇÃO - SIPREM
% Aba 1: Consolidado
% Aba 2: Dados_Brutos
% ---------------------------------------------------------

arquivo_resultado = ...
    'Resultado_SIPREM_FAHP_FuzzyPromethee_Geldermann.xlsx';

%% =========================================================
% TABELA COMPLETA — DADOS BRUTOS
% =========================================================

T_res = table( ...
    req_labels(:), ...
    IDs(:), ...
    Phi_plus_fuzzy(:,1), ...
    Phi_plus_fuzzy(:,2), ...
    Phi_plus_fuzzy(:,3), ...
    Phi_plus_fuzzy(:,4), ...
    Phi_minus_fuzzy(:,1), ...
    Phi_minus_fuzzy(:,2), ...
    Phi_minus_fuzzy(:,3), ...
    Phi_minus_fuzzy(:,4), ...
    Phi_net_fuzzy(:,1), ...
    Phi_net_fuzzy(:,2), ...
    Phi_net_fuzzy(:,3), ...
    Phi_net_fuzzy(:,4), ...
    Phi_plus(:), ...
    Phi_minus(:), ...
    phi_net(:), ...
    cat(:), ...
    'VariableNames', { ...
        'Req', ...
        'ID', ...
        'PhiPlus_a', ...
        'PhiPlus_b', ...
        'PhiPlus_c', ...
        'PhiPlus_d', ...
        'PhiMinus_a', ...
        'PhiMinus_b', ...
        'PhiMinus_c', ...
        'PhiMinus_d', ...
        'PhiNet_a', ...
        'PhiNet_b', ...
        'PhiNet_c', ...
        'PhiNet_d', ...
        'Phi_Plus', ...
        'Phi_Minus', ...
        'Net_Flow', ...
        'Categoria'});

% Ordena pelo fluxo líquido, do maior para o menor
T_res = sortrows(T_res, 'Net_Flow', 'descend');

% Cria o ranking após a ordenação
T_res.Rank = (1:height(T_res))';

% Move Rank para a primeira coluna
T_res = movevars(T_res, 'Rank', 'Before', 'Req');

%% =========================================================
% TABELA CONSOLIDADA
% =========================================================

T_consolidado = T_res(:, { ...
    'Rank', ...
    'Req', ...
    'Phi_Plus', ...
    'Phi_Minus', ...
    'Net_Flow', ...
    'Categoria'});

% Renomeia as colunas da tabela resumida
T_consolidado.Properties.VariableNames = { ...
    'Rank', ...
    'Requisito', ...
    'Phi_Plus', ...
    'Phi_Minus', ...
    'Phi_Liquido', ...
    'Categoria'};

%% =========================================================
% EXIBIÇÃO NO COMMAND WINDOW
% =========================================================

disp('Top 10 requisitos - Cenário SIPREM:');
disp(head(T_consolidado, min(10,height(T_consolidado))));

%% =========================================================
% EXPORTAÇÃO PARA O MESMO ARQUIVO EXCEL
% =========================================================

% Apaga o arquivo anterior, se ele existir
if isfile(arquivo_resultado)
    try
        delete(arquivo_resultado);
    catch
        error(['Não foi possível substituir o arquivo. ', ...
               'Feche o arquivo no Excel e execute novamente: ', ...
               arquivo_resultado]);
    end
end

% Aba resumida para apresentação
writetable( ...
    T_consolidado, ...
    arquivo_resultado, ...
    'Sheet', 'Consolidado');

% Aba completa para auditoria
writetable( ...
    T_res, ...
    arquivo_resultado, ...
    'Sheet', 'Dados_Brutos');

fprintf('\nArquivo criado com sucesso:\n');
fprintf('%s\n', arquivo_resultado);
fprintf('Aba 1: Consolidado\n');
fprintf('Aba 2: Dados_Brutos\n');



rank_SIPREM = nReq + 1 - tiedrank(phi_net(:));


%% =========================================================
% CORRELAÇÃO DOS FLUXOS LÍQUIDOS
%% =========================================================

phi_all = [phi_net_experts,...
           phi_net(:)];

labels_phi = [all_sheets(:); ...
              {'GrupoSIPREM'}];

rho_phi_spear = corr(phi_all,...
                     'Type','Spearman');

rho_phi_pear = corr(phi_all,...
                    'Type','Pearson');

disp(' ')
disp('--- SPEARMAN DOS FLUXOS LIQUIDOS ---')
disp(array2table(rho_phi_spear,...
    'VariableNames',labels_phi,...
    'RowNames',labels_phi))

disp(' ')
disp('--- PEARSON DOS FLUXOS LIQUIDOS ---')
disp(array2table(rho_phi_pear,...
    'VariableNames',labels_phi,...
    'RowNames',labels_phi))
%% =========================================================
% 10A. CLASSIFICAÇÕES DE TODAS AS FONTES
%% =========================================================

% SIPREM: já foi calculada acima como "cat"
cat_SIPREM = cat;

% especialistas individuais
cat_exp = strings(nReq, nExperts);

for e = 1:nExperts
    key_e = find(impacto_ind(:,e) == scale_max(1));   % key do próprio especialista
        cat_exp(:,e) = classify_requirements_kmeans(phi_net_experts(:,e), key_e);
end


%% =========================================================
% CONCORDÂNCIA DAS CLASSIFICAÇÕES
% WEIGHTED COHEN'S KAPPA
%
% Ordem das categorias:
%   Key > G1 > G2 > G3
%
% Ponderação quadrática:
%   desacordos distantes recebem penalidade maior
%% =========================================================

% Organização das fontes:
% E1, E2, ..., En e SIPREM
classes_kappa = [ ...
    cat_exp, ...
    cat_SIPREM(:)];

nFontesKappa = size(classes_kappa,2);

% Rótulos das fontes
labels_kappa = strings(nFontesKappa,1);

for e = 1:nExperts
    labels_kappa(e) = sprintf('E%d',e);
end

labels_kappa(nExperts+1) = "SIPREM";

%% ---------------------------------------------------------
% Conversão das categorias em códigos ordinais
%
% Key = 1
% G1  = 2
% G2  = 3
% G3  = 4
%% ---------------------------------------------------------

classes_codigo = zeros(size(classes_kappa));

for j = 1:nFontesKappa
    classes_codigo(:,j) = classToCode(classes_kappa(:,j));
end

%% ---------------------------------------------------------
% Matriz par a par de Weighted Cohen's Kappa
%% ---------------------------------------------------------

kappa_ponderado = nan(nFontesKappa,nFontesKappa);

for a = 1:nFontesKappa

    for b = 1:nFontesKappa

        kappa_ponderado(a,b) = weightedCohenKappa( ...
            classes_codigo(:,a), ...
            classes_codigo(:,b), ...
            4, ...
            'quadratic');

    end
end

%% ---------------------------------------------------------
% Exibição no Command Window
%% ---------------------------------------------------------

nomes_kappa_validos = matlab.lang.makeValidName( ...
    cellstr(labels_kappa));

T_kappa_ponderado = array2table( ...
    kappa_ponderado, ...
    'VariableNames',nomes_kappa_validos, ...
    'RowNames',cellstr(labels_kappa));

disp(' ');
disp('============================================================');
disp('WEIGHTED COHEN''S KAPPA DAS CLASSIFICAÇÕES');
disp('Categorias: Key, G1, G2 e G3');
disp('Ponderação: quadrática');
disp('============================================================');
disp(T_kappa_ponderado);

%% ---------------------------------------------------------
% Exportação da matriz para Excel
%% ---------------------------------------------------------

writetable( ...
    T_kappa_ponderado, ...
    'Concordancia_Classificacoes_Kappa.xlsx', ...
    'Sheet','Kappa_Quadratico', ...
    'WriteRowNames',true);

%% ---------------------------------------------------------
% Heatmap do Weighted Cohen's Kappa
%% ---------------------------------------------------------

fig_kappa = figure( ...
    'Color','w', ...
    'Position',[130 80 900 760], ...
    'Visible','off', ...
    'Name', ...
    'Concordância das classificações - Weighted Cohen Kappa', ...
    'NumberTitle','off');

imagesc(kappa_ponderado);

axis square;
box on;

% O Kappa pode variar de -1 a 1
caxis([-1 1]);

colormap(fig_kappa,parula);

cb = colorbar;
cb.Label.String = 'Weighted Cohen''s Kappa';

title( ...
    {'Concordância das classificações entre especialistas e SIPREM', ...
     'Weighted Cohen''s Kappa com ponderação quadrática'}, ...
    'FontSize',13, ...
    'FontWeight','bold');

xlabel('Fonte de classificação');
ylabel('Fonte de classificação');

xticks(1:nFontesKappa);
yticks(1:nFontesKappa);

xticklabels(labels_kappa);
yticklabels(labels_kappa);

xtickangle(45);

%% ---------------------------------------------------------
% Valores dentro das células
%% ---------------------------------------------------------

for i = 1:nFontesKappa

    for j = 1:nFontesKappa

        valor = kappa_ponderado(i,j);

        if isnan(valor)

            texto_valor = 'NaN';
            cor_texto = 'k';

        else

            texto_valor = sprintf('%.3f',valor);

            % No parula, valores menores tendem a ser mais escuros
            if valor < 0.15
                cor_texto = 'w';
            else
                cor_texto = 'k';
            end

        end

        text( ...
            j,i, ...
            texto_valor, ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontSize',9, ...
            'FontWeight','bold', ...
            'Color',cor_texto);

    end
end

set(gca, ...
    'TickLength',[0 0], ...
    'FontSize',10, ...
    'Layer','top');

drawnow;

%% =========================================================
% CLASSIFICAÇÃO FINAL PARA STAKEHOLDERS
%% =========================================================

T_final = table(req_labels(:), ...
                IDs, ...
                phi_net(:), ...
                rank_SIPREM(:), ...
                cat(:), ...
                alerta_div(:), ...
    'VariableNames',{'Req','ID','PhiNet','Rank','Categoria','Alerta_Divergencia'});

T_final = sortrows(T_final,'Rank');

disp('CLASSIFICAÇÃO FINAL DOS REQUISITOS')
disp(T_final)

writetable(T_final,'Classificacao_Final_Requisitos.xlsx')
%% =========================================================
% COMPARAÇÃO COMPLETA DOS RANKINGS + CLASSIFICAÇÕES
%% =========================================================

vars = {req_labels(:)};

varNames = {'Req'};

for e = 1:nExperts

    vars{end+1} = rank_matrix(:,e);
    vars{end+1} = cat_exp(:,e);

    varNames{end+1} = sprintf('Rank_E%d',e);
    varNames{end+1} = sprintf('Classe_E%d',e);

end

vars{end+1} = rank_SIPREM(:);
vars{end+1} = cat_SIPREM(:);

varNames{end+1} = 'Rank_SIPREM';
varNames{end+1} = 'Classe_SIPREM';

T_rank_all = table(vars{:},...
                   'VariableNames',varNames);

writetable(T_rank_all,'Comparacao_Todos_Rankings.xlsx')
disp(' ')
disp('--- COMPARAÇÃO COMPLETA DOS RANKINGS + CLASSIFICAÇÕES ---')
disp(T_rank_all)


%% =========================================================
% DIFERENÇAS DE RANKING E DE CLASSIFICAÇÃO (ESPECIALISTA vs GRUPO SIPREM)
% Histogramas (visão geral) + boxplots paginados (todos os requisitos)
%% =========================================================

nomes_especialistas = string(all_sheets(:));

% --- códigos ordinais das classes: Key=1, G1=2, G2=3, G3=4 ---
classe_codigo_exp = zeros(nReq,nExperts);
for e = 1:nExperts
    classe_codigo_exp(:,e) = classToCode(cat_exp(:,e));
end
classe_codigo_SIPREM = classToCode(cat_SIPREM(:));

% --- diferenças (especialista - grupo) ---
delta_rank_exp   = rank_matrix(:,1:nExperts) - rank_SIPREM(:);
abs_delta_rank   = abs(delta_rank_exp);
abs_delta_classe = abs(classe_codigo_exp - classe_codigo_SIPREM);

nColunas = min(3,nExperts);
nLinhas  = ceil(nExperts/nColunas);

% ---------------------------------------------------------
% Histogramas de |Delta Rank|
% ---------------------------------------------------------
figure('Color','w','Position',[80 60 430*nColunas 320*nLinhas], ...
       'Name','Histogramas das diferenças absolutas de ranking','NumberTitle','off');
tiledlayout(nLinhas,nColunas,'TileSpacing','compact','Padding','compact');

max_delta_rank_h = max(1,ceil(max(abs_delta_rank,[],'all')));
passo_bins = max(1,ceil(max_delta_rank_h/40));   % agrupa barras se a escala for grande

for e = 1:nExperts
    nexttile;
    histogram(abs_delta_rank(:,e), ...
        'BinEdges',-0.5:passo_bins:(max_delta_rank_h+passo_bins), 'FaceAlpha',0.80);
    title(sprintf('%s versus Grupo SIPREM',nomes_especialistas(e)), ...
        'Interpreter','none','FontWeight','bold');
    xlabel('|\Delta Rank|');
    ylabel('Número de requisitos');
    grid on; box on;
    media_e = mean(abs_delta_rank(:,e));
    xline(media_e,'--',sprintf('Média = %.2f',media_e), ...
        'LabelVerticalAlignment','middle','LabelHorizontalAlignment','left','LineWidth',1.4);
end
sgtitle({'Diferença absoluta entre os rankings individuais e o ranking consolidado', ...
         'Valores menores indicam maior aderência ao resultado do grupo'}, ...
        'FontSize',14,'FontWeight','bold');

% ---------------------------------------------------------
% Histogramas de |Delta Classe|
% ---------------------------------------------------------
figure('Color','w','Position',[80 60 430*nColunas 320*nLinhas], ...
       'Name','Histogramas das diferenças de classificação','NumberTitle','off');
tiledlayout(nLinhas,nColunas,'TileSpacing','compact','Padding','compact');

for e = 1:nExperts
    nexttile;
    histogram(abs_delta_classe(:,e),'BinEdges',-0.5:1:3.5,'FaceAlpha',0.80);
    title(sprintf('%s versus Grupo SIPREM',nomes_especialistas(e)), ...
        'Interpreter','none','FontWeight','bold');
    xlabel('|\Delta Classe|');
    ylabel('Número de requisitos');
    xticks(0:3);
    xticklabels({'0: igual','1 categoria','2 categorias','3 categorias'});
    xtickangle(20);
    xlim([-0.5 3.5]);
    grid on; box on;
    media_e = mean(abs_delta_classe(:,e));
    xline(media_e,'--',sprintf('Média = %.2f',media_e), ...
        'LabelVerticalAlignment','middle','LabelHorizontalAlignment','left','LineWidth',1.4);
end
sgtitle({'Diferença absoluta entre as classificações individuais e a consolidada', ...
         'Categorias ordinais: Key, G1, G2 e G3'}, ...
        'FontSize',14,'FontWeight','bold');

% ---------------------------------------------------------
% Resumo no Command Window
% ---------------------------------------------------------
T_resumo_dif = table(nomes_especialistas, ...
    mean(abs_delta_rank,1)', median(abs_delta_rank,1)', max(abs_delta_rank,[],1)', ...
    100*mean(abs_delta_rank<=3,1)', ...
    mean(abs_delta_classe,1)', 100*mean(abs_delta_classe==0,1)', ...
    'VariableNames',{'Especialista','Media_AbsDeltaRank','Mediana_AbsDeltaRank', ...
                     'Max_AbsDeltaRank','Pct_Rank_ate3','Media_AbsDeltaClasse', ...
                     'Pct_MesmaClasse'});
T_resumo_dif = sortrows(T_resumo_dif,'Media_AbsDeltaRank','ascend');
disp(' ');
disp('--- ADERÊNCIA DOS ESPECIALISTAS AO GRUPO SIPREM ---');
disp(T_resumo_dif);



%% =========================================================
% RESUMO ANALÍTICO
%% =========================================================
disp(' ');
disp('============================================================');
disp('RESUMO ANALÍTICO DOS RESULTADOS');
disp('============================================================');

disp(' ');
disp('--- PESOS DOS CRITÉRIOS (FAHP-Express, grupo) ---');
T_pesos = table(crit_names(:), ...
    w_fuzzy_group(:,1), w_fuzzy_group(:,2), w_fuzzy_group(:,3), w_fuzzy_group(:,4), ...
    w_group_defuzz(:), ...
    'VariableNames', {'Criterio','w_a','w_b','w_c','w_d','w_defuzz'});
disp(T_pesos);

for e = 1:nExperts
    rho_e = corr(rank_matrix(:,e), rank_matrix(:,end), 'Type', 'Spearman');
    fprintf('Spearman entre %s e Grupo SIPREM = %.4f\n', all_sheets{e}, rho_e);
end

[~, idx_SIPREM] = sort(phi_net, 'descend');

Top10_SIPREM = table(req_labels(idx_SIPREM(1:min(10,nReq)))', ...
    phi_net(idx_SIPREM(1:min(10,nReq))), ...
    rank_SIPREM(idx_SIPREM(1:min(10,nReq))), ...
    'VariableNames', {'Req','PhiNet_SIPREM','Rank_SIPREM'});

disp(' ');
disp('--- TOP 10 SIPREM ---');
disp(Top10_SIPREM);

%% =========================================================
% 12. FIGURA 1 - HEATMAP DE POSIÇÕES
%% =========================================================
pags_req = paginarRequisitos(nReq, req_por_pagina);
nPag = numel(pags_req);

fig_posicoes_pgs = gobjects(nPag,1);

for pg = 1:nPag

    idx  = pags_req{pg};
    nLin = numel(idx);

    fig_posicoes_pgs(pg) = figure( ...
        'Color','w', ...
        'Position',[100 40 900 max(420, 24*nLin + 160)], ...
        'Visible','on', ...
        'Name',sprintf('Heatmap das posições no ranking (pág. %d de %d)',pg,nPag), ...
        'NumberTitle','off');

    imagesc(rank_matrix_ord(idx,:));
    colormap(flipud(parula));
    colorbar;
    caxis([1 nReq]);   % mesma escala em todas as páginas

    title({'Heatmap das posições no ranking: especialistas vs grupo SIPREM', ...
           sprintf('Posições %d a %d no ranking SIPREM (pág. %d de %d)', ...
                   idx(1), idx(end), pg, nPag)}, ...
        'FontSize', 13, 'FontWeight', 'bold');

    xticks(1:(nExperts+1));
    xticklabels(col_names);

    lab_y = arrayfun(@(i) sprintf('%s (#%d)', req_labels_ord{i}, ...
                     rank_matrix_ord(i,end)), idx, 'UniformOutput', false);
    yticks(1:nLin);
    yticklabels(lab_y);

    xlabel('Fonte de avaliação');
    ylabel('Requisito (posição SIPREM)');

    for i = 1:nLin
        for j = 1:(nExperts+1)
            v = rank_matrix_ord(idx(i),j);
            if v > 0.7*nReq
                cor_txt = 'w';
            else
                cor_txt = 'k';
            end
            text(j, i, num2str(v), ...
                'HorizontalAlignment', 'center', ...
                'FontSize', 9, 'FontWeight', 'bold', 'Color', cor_txt);
        end
    end

    set(gca, 'TickLength', [0 0], 'FontSize', 9);
    box on;
    drawnow;
end

%% =========================================================
% 13. FIGURA 2 - PESOS FUZZY DOS CRITÉRIOS
%% =========================================================
figure('Color','w','Position',[110 100 950 500]);
hold on;

x = 1:nCrit;
bar(x, w_group_defuzz, 0.55, ...
    'FaceColor', [0.75 0.85 0.95], ...
    'EdgeColor', 'k');

for k = 1:nCrit
    wf = w_fuzzy_group(k,:);

    plot([k k], [wf(1) wf(4)], '-', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5);
    plot([k k], [wf(2) wf(3)], '-', 'Color', 'k', 'LineWidth', 5);

    plot(k, wf(1), 'o', 'MarkerFaceColor', [0.6 0.6 0.6], 'MarkerEdgeColor', 'k', 'MarkerSize', 5);
    plot(k, wf(4), 'o', 'MarkerFaceColor', [0.6 0.6 0.6], 'MarkerEdgeColor', 'k', 'MarkerSize', 5);
end

set(gca, 'XTick', x, 'XTickLabel', crit_names, 'FontSize', 11);
xtickangle(20);
ylabel('Peso');
title('Pesos fuzzy dos critérios obtidos pelo FAHP-Express', ...
    'FontSize', 13, 'FontWeight', 'bold');
grid on;
box on;
hold off;

%% =========================================================
% HEATMAP DE CONCORDÂNCIA ENTRE ESPECIALISTAS E SIPREM
%
% Medidas:
%   1) Spearman Footrule normalizada
%   2) Kendall Tau-b
%
% Fontes comparadas:
%   E1, E2, ..., En e SIPREM
%% =========================================================

fprintf('\n');
fprintf('============================================================\n');
fprintf('CONCORDÂNCIA ENTRE ESPECIALISTAS E SIPREM\n');
fprintf('============================================================\n');

%% ---------------------------------------------------------
% 1. MATRIZ COM TODOS OS RANKINGS
%% ---------------------------------------------------------

% rank_matrix(:,1:nExperts) = rankings individuais

% rank_SIPREM                   = ranking coletivo do cenário SIPREM

rankings_concordancia = [ ...
    rank_matrix(:,1:nExperts), ...
    rank_SIPREM(:)];

nFontes = size(rankings_concordancia,2);

labels_concordancia = strings(nFontes,1);

for e = 1:nExperts
    labels_concordancia(e) = sprintf('E%d',e);
end

labels_concordancia(nExperts+1) = "SIPREM";

% Nomes válidos para as colunas das tabelas MATLAB
nomes_validos = matlab.lang.makeValidName( ...
    cellstr(labels_concordancia));

%% ---------------------------------------------------------
% 2. SPEARMAN FOOTRULE NORMALIZADA
%% ---------------------------------------------------------
%
% Distância Footrule:
%
% F(A,B) = sum_i |r_i^A - r_i^B|
%
% Distância máxima para n elementos:
%
% F_max = floor(n^2/2)
%
% Índice normalizado de concordância:
%
% IC_F = 1 - F/F_max
%
% Interpretação:
%   1 = rankings idênticos
%   0 = distância máxima teórica
%% ---------------------------------------------------------

F_max = floor(nReq^2/2);

IC_footrule = zeros(nFontes,nFontes);
D_footrule  = zeros(nFontes,nFontes);

for a = 1:nFontes

    rank_a = rankings_concordancia(:,a);

    for b = 1:nFontes

        rank_b = rankings_concordancia(:,b);

        % Distância absoluta total entre as posições
        distancia_ab = sum( ...
            abs(rank_a-rank_b), ...
            'omitnan');

        D_footrule(a,b) = distancia_ab;

        % Footrule normalizada como índice de concordância
        IC_footrule(a,b) = 1-distancia_ab/F_max;

        % Proteção contra pequenos erros numéricos ou presença de empates
        IC_footrule(a,b) = max( ...
            0, ...
            min(1,IC_footrule(a,b)));

    end
end


%% ---------------------------------------------------------
% 4. EXIBIÇÃO DAS MATRIZES NO COMMAND WINDOW
%% ---------------------------------------------------------

T_footrule = array2table( ...
    IC_footrule, ...
    'VariableNames',nomes_validos, ...
    'RowNames',cellstr(labels_concordancia));


T_distancia_footrule = array2table( ...
    D_footrule, ...
    'VariableNames',nomes_validos, ...
    'RowNames',cellstr(labels_concordancia));

disp(' ');
disp('--- SPEARMAN FOOTRULE NORMALIZADA ---');
disp(T_footrule);

disp(' ');
disp('--- DISTÂNCIA FOOTRULE NÃO NORMALIZADA ---');
disp(T_distancia_footrule);



%% ---------------------------------------------------------
% 5. HEATMAP — SPEARMAN FOOTRULE NORMALIZADA
%% ---------------------------------------------------------

fig_footrule = figure( ...
    'Color','w', ...
    'Position',[100 80 900 760], ...
    'Visible','off', ...
    'Name', ...
    'Concordância entre especialistas e S2 - Spearman Footrule normalizada', ...
    'NumberTitle','off');

% O heatmap precisa ser criado depois da figura definitiva
imagesc(IC_footrule);

axis square;
box on;

colormap(fig_footrule,parula);

cb = colorbar;
cb.Label.String = 'Concordância Footrule normalizada';

caxis([0 1]);

title( ...
    {'Concordância entre especialistas e SIPREM', ...
     'Spearman Footrule normalizada'}, ...
    'FontSize',13, ...
    'FontWeight','bold');

xticks(1:nFontes);
yticks(1:nFontes);

xticklabels(labels_concordancia);
yticklabels(labels_concordancia);

xtickangle(45);

xlabel('Fonte de avaliação');
ylabel('Fonte de avaliação');

% Valores dentro das células
for i = 1:nFontes

    for j = 1:nFontes

        valor = IC_footrule(i,j);

        % Texto branco nas células escuras
        if valor < 0.55
            cor_texto = 'w';
        else
            cor_texto = 'k';
        end

        text( ...
            j,i, ...
            sprintf('%.3f',valor), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontSize',9, ...
            'FontWeight','bold', ...
            'Color',cor_texto);

    end
end

set(gca, ...
    'TickLength',[0 0], ...
    'FontSize',10, ...
    'Layer','top');

drawnow;

%% ---------------------------------------------------------
% 7. INDICADORES INDIVIDUAIS DOS ESPECIALISTAS
%% ---------------------------------------------------------
%
% Para cada especialista:
%
% - concordância média com os demais especialistas;
% - concordância com SIPREM.
%% ---------------------------------------------------------

foot_media_pares = zeros(nExperts,1);
foot_com_SIPREM      = zeros(nExperts,1);

for e = 1:nExperts

    outros = setdiff(1:nExperts,e);

    foot_media_pares(e) = mean( ...
        IC_footrule(e,outros), ...
        'omitnan');

    foot_com_SIPREM(e) = IC_footrule(e,nExperts+1);

end

Especialista_heatmap = strings(nExperts,1);

for e = 1:nExperts
    Especialista_heatmap(e) = sprintf('E%d',e);
end

T_resumo_concordancia = table( ...
    Especialista_heatmap, ...
    foot_media_pares, ...
    foot_com_SIPREM, ...
    'VariableNames',{ ...
        'Especialista', ...
        'Footrule_Media_Com_Pares', ...
        'Footrule_Com_SIPREM'});

disp(' ');
disp('--- RESUMO DA CONCORDÂNCIA DOS ESPECIALISTAS ---');
disp(T_resumo_concordancia);

%% ---------------------------------------------------------
% 8. EXPORTAÇÃO PARA EXCEL
%% ---------------------------------------------------------

arquivo_heatmaps = ...
    'Concordancia_Rankings_Especialistas_SIPREM.xlsx';

if isfile(arquivo_heatmaps)

    try
        delete(arquivo_heatmaps);

    catch
        error([ ...
            'Não foi possível substituir o arquivo ', ...
            arquivo_heatmaps, ...
            '. Feche-o no Excel e execute novamente.']);

    end
end

writetable( ...
    T_footrule, ...
    arquivo_heatmaps, ...
    'Sheet','Footrule_Normalizada', ...
    'WriteRowNames',true);

writetable( ...
    T_distancia_footrule, ...
    arquivo_heatmaps, ...
    'Sheet','Distancia_Footrule', ...
    'WriteRowNames',true);



writetable( ...
    T_resumo_concordancia, ...
    arquivo_heatmaps, ...
    'Sheet','Resumo_Especialistas');

fprintf('\nArquivos de concordância criados:\n');
fprintf('%s\n',arquivo_heatmaps);


%% =========================================================
% KENDALL W DOS PESOS FAHP
%% =========================================================

% Defuzzificação dos pesos fuzzy individuais
w_defuzz_individual = zeros(nCrit,nExperts);

for e = 1:nExperts

    for k = 1:nCrit

        wf = squeeze(info_SIPREM.w_fuzzy_individual(k,:,e));

        % Centroide para trapézio
        w_defuzz_individual(k,e) = ...
            (wf(1) + 2*wf(2) + 2*wf(3) + wf(4))/6;

    end

end

% Ranking dos critérios para cada especialista
rank_weights = zeros(size(w_defuzz_individual));

for e = 1:nExperts

    rank_weights(:,e) = tiedrank(-w_defuzz_individual(:,e));

end

% Kendall W
R = rank_weights;

[n,m] = size(R);

Ri = sum(R,2);
Rbar = mean(Ri);

S = sum((Ri - Rbar).^2);

W_fahp = 12*S/(m^2*(n^3-n));

chi2_fahp = m*(n-1)*W_fahp;

p_fahp = 1 - chi2cdf(chi2_fahp,n-1);

disp(' ')
disp('========================================')
disp('KENDALL W DOS PESOS FAHP')
disp('========================================')

fprintf('W = %.4f\n',W_fahp);
fprintf('Chi2 = %.4f\n',chi2_fahp);
fprintf('p-value = %.6f\n',p_fahp);

%% kendel

R = rank_matrix(:,1:nExperts);

[n,m] = size(R);

% soma dos ranks por requisito
Ri = sum(R,2);

% rank médio total
Rbar = mean(Ri);

% estatística S
S = sum((Ri - Rbar).^2);

% Kendall W
W = 12*S / (m^2*(n^3 - n));

fprintf('Kendall W = %.4f\n',W);

chi2 = m*(n-1)*W;

p = 1 - chi2cdf(chi2,n-1);

fprintf('Chi2 = %.4f\n',chi2);
fprintf('p-value = %.6f\n',p);

%% =========================================================
% PROMETHEE I - CENÁRIO SIPREM
% =========================================================

nReq = length(Phi_plus);

relation_SIPREM = zeros(nReq); % matriz de relações PROMETHEE I - SIPREM

for i = 1:nReq
    for j = 1:nReq
        if i == j
            relation_SIPREM(i,j) = 0;
            continue
        end

        if Phi_plus(i) > Phi_plus(j) && Phi_minus(i) < Phi_minus(j)
            relation_SIPREM(i,j) = 1;    % i domina j (P)

        elseif Phi_plus(i) < Phi_plus(j) && Phi_minus(i) > Phi_minus(j)
            relation_SIPREM(i,j) = -1;   % j domina i (P-)

        elseif Phi_plus(i) > Phi_plus(j) && Phi_minus(i) > Phi_minus(j)
            relation_SIPREM(i,j) = 2;    % incomparável (R)

        elseif Phi_plus(i) < Phi_plus(j) && Phi_minus(i) < Phi_minus(j)
            relation_SIPREM(i,j) = 2;    % incomparável (R)

        else
            relation_SIPREM(i,j) = 0;    % indiferença (I)
        end
    end
end
%% =========================================================
% MATRIZ DE RELAÇÕES PROMETHEE I - SIPREM (COM LEGENDA)
% =========================================================
figure('Color','w','Position',[310 210 720 620])

imagesc(relation_SIPREM)

% Colormap discreto (ordem: -1, 0, 1, 2)
cmap = [
    0.2 0.2 0.8   % azul   → P- (dominado)
    0.7 0.7 0.7   % cinza  → I (indiferente)
    0.2 0.7 0.2   % verde  → P (domina)
    0.9 0.8 0.2   % amarelo→ R (incomparável)
];

colormap(cmap)

% Ajuste da escala
caxis([-1 2])

% Colorbar com significado
colorbar('Ticks',[-1 0 1 2], ...
         'TickLabels',{'P- (Dominado)','I (Indiferente)','P (Domina)','R (Incomparável)'})

title('Relações do Fuzzy PROMETHEE I no SIPREM', ...
    'FontSize', 13, ...
    'FontWeight', 'bold');

xlabel('Requisito j');
ylabel('Requisito i');
tk = 1:ceil(nReq/40):nReq;   % rótulos espaçados quando há muitos requisitos
set(gca,'XTick',tk,'XTickLabel',req_labels(tk))
set(gca,'YTick',tk,'YTickLabel',req_labels(tk))

xtickangle(90)
grid on
box on

%% =========================================================
% EXPORTAR MATRIZ DE RELAÇÕES PROMETHEE I - SIPREM
% =========================================================
rel_matrix_text_SIPREM = cell(nReq, nReq);

for i = 1:nReq
    for j = 1:nReq
        if i == j
            rel_matrix_text_SIPREM{i,j} = '-';
        else
            switch relation_SIPREM(i,j)
                case 1
                    rel_matrix_text_SIPREM{i,j} = 'P (Outranks)';
                case -1
                    rel_matrix_text_SIPREM{i,j} = 'P- (Outranked)';
                case 2
                    rel_matrix_text_SIPREM{i,j} = 'R (Incomparable)';
                case 0
                    rel_matrix_text_SIPREM{i,j} = 'I (Indifferent)';
            end
        end
    end
end

T_rel_matrix_SIPREM = cell2table(rel_matrix_text_SIPREM, ...
    'VariableNames', req_labels, ...
    'RowNames', req_labels);

writetable(T_rel_matrix_SIPREM, 'PROMETHEE_I_Relation_Matrix_SIPREM.xlsx', 'WriteRowNames', true);

% disp(' ')
% disp('--- PROMETHEE I relation matrix exported for SIPREM ---')
% disp('File: PROMETHEE_I_Relation_Matrix_SIPREM.xlsx')



%% =========================================================
% GAIA PLANE FIEL AO PROMETHEE (via fluxos líquidos unicritério)
%% =========================================================

% Matriz dos fluxos líquidos unicritério do cenário SIPREM agregado
% linhas = requisitos
% colunas = critérios
Phi_uni = computeUnicriterionNetFlows(F, w_group_defuzz, critDir, pref_types, q_vals, p_vals);

% Normalização/centragem para GAIA
Phi_uni_z = zscore(Phi_uni);

% PCA sobre a matriz de fluxos unicritério
[coeff_gaia, score_gaia, latent_gaia] = pca(Phi_uni_z);

U = score_gaia(:,1);
V = score_gaia(:,2);

% Delta do plano GAIA
delta_gaia = 100 * sum(latent_gaia(1:min(2,end))) / sum(latent_gaia);

fprintf('\nDelta do plano GAIA = %.2f%%\n', delta_gaia);

if delta_gaia >= 80
    fprintf('Interpretação: plano GAIA muito representativo.\n');
elseif delta_gaia >= 60
    fprintf('Interpretação: plano GAIA razoavelmente representativo.\n');
else
    fprintf('Interpretação: plano GAIA deve ser interpretado com cautela.\n');
end

figure('Color','w','Position',[260 160 920 700])
hold on

% alternativas
scatter(U, V, 80, phi_net, 'filled')
colorbar
colormap(parula)

for i = 1:nReq
    text(U(i), V(i), req_labels{i}, 'FontSize', 9)
end

% vetores dos critérios
for k = 1:nCrit
    quiver(0, 0, coeff_gaia(k,1), coeff_gaia(k,2), 0, ...
        'LineWidth', 2, 'Color', 'k');

    text(coeff_gaia(k,1)*1.15, coeff_gaia(k,2)*1.15, crit_names{k}, ...
        'FontWeight', 'bold');
end

% vetor de decisão (pi-stick aproximado pelos pesos no espaço projetado)
decision_stick = w_group_defuzz(:)' * coeff_gaia(:,1:2);
quiver(0, 0, decision_stick(1), decision_stick(2), 0, ...
    'LineWidth', 3, 'LineStyle', '--', 'Color', [0.2 0.2 0.2]);

text(decision_stick(1)*1.08, decision_stick(2)*1.08, 'Pi', ...
    'FontWeight', 'bold', 'FontSize', 11, 'Color', [0.2 0.2 0.2]);

xlabel(sprintf('GAIA axis 1 (%.1f%%)', 100*latent_gaia(1)/sum(latent_gaia)))
ylabel(sprintf('GAIA axis 2 (%.1f%%)', 100*latent_gaia(2)/sum(latent_gaia)))
title(sprintf('GAIA plane baseado em fluxos líquidos unicritério (\\delta = %.2f%%)', delta_gaia), ...
    'FontWeight', 'bold')

text(min(U), max(V)*1.06, ...
    sprintf('\\delta = %.2f%% da informação preservada no plano', delta_gaia), ...
    'FontSize', 11, 'FontWeight', 'bold')

grid on
axis equal
box on
hold off

%% =========================================================
% HEATMAP DAS CLASSIFICAÇÕES
%% =========================================================

cat_matrix = [cat_exp, cat_SIPREM];

cat_labels = cell(1,nExperts+1);

for e = 1:nExperts
    cat_labels{e} = sprintf('E%d',e);
end

cat_labels{nExperts+1} = 'SIPREM';

cat_code = zeros(size(cat_matrix));

for j = 1:size(cat_matrix,2)
    cat_code(:,j) = classToCode(cat_matrix(:,j));
end

[~, ord_cat] = sort(rank_SIPREM,'ascend');

pags_cls = paginarRequisitos(nReq, req_por_pagina);
nPagCls  = numel(pags_cls);

fig_classificacoes_pgs = gobjects(nPagCls,1);

for pg = 1:nPagCls

    idx  = pags_cls{pg};
    nLin = numel(idx);
    ord_pg = ord_cat(idx);

    fig_classificacoes_pgs(pg) = figure( ...
        'Color','w', ...
        'Position',[120 40 900 max(420, 24*nLin + 160)], ...
        'Visible','on', ...
        'Name',sprintf('Heatmap das classificações (pág. %d de %d)',pg,nPagCls), ...
        'NumberTitle','off');

    imagesc(cat_code(ord_pg,:));
    colormap(parula(4));
    caxis([0.5 4.5]);

    colorbar('Ticks',1:4,...
             'TickLabels',{'Key','G1','G2','G3'});

    title({'Heatmap das classificações por fonte', ...
           sprintf('Posições %d a %d no ranking SIPREM (pág. %d de %d)', ...
                   idx(1), idx(end), pg, nPagCls)}, ...
          'FontSize',13,'FontWeight','bold');

    xlabel('Fonte');
    ylabel('Requisito (posição SIPREM)');

    xticks(1:numel(cat_labels));
    xticklabels(cat_labels);

    lab_y = arrayfun(@(i) sprintf('%s (#%d)', req_labels{ord_cat(i)}, i), ...
                     idx, 'UniformOutput', false);
    yticks(1:nLin);
    yticklabels(lab_y);

    for i = 1:nLin
        for j = 1:size(cat_code,2)

            if cat_code(ord_pg(i),j) == 1
                cor_txt = 'w';    % Key (azul escuro)
            else
                cor_txt = 'k';
            end

            text(j,i,string(cat_matrix(ord_pg(i),j)),...
                'HorizontalAlignment','center',...
                'FontSize',9,...
                'FontWeight','bold',...
                'Color',cor_txt);
        end
    end

    set(gca,'TickLength',[0 0],'FontSize',9);
    box on;
    drawnow;
end

%% =========================================================
% TABELA FINAL: RANK + GRUPO + INCOMPARABILIDADE LOCAL
% Regras:
% 1) vizinho imediato acima/abaixo
% 2) contagem global de incomparabilidades
% 3) checagem ampliada de 3 posicoes acima/abaixo
% =========================================================

% ordenar pelo ranking SIPREM (PROMETHEE II)
[~, ord_rank] = sort(rank_SIPREM, 'ascend');

Req_ord   = req_labels(ord_rank);
Rank_ord  = rank_SIPREM(ord_rank);
Phi_ord   = phi_net(ord_rank);
Grupo_ord = cat(ord_rank);

% se IDs existir no seu workspace, use:
if exist('IDs','var')
    ID_ord = IDs(ord_rank);
else
    ID_ord = (1:nReq)';
    ID_ord = ID_ord(ord_rank);
end

% ---------------------------------------------------------
% REGRA 2: contagem global de incomparabilidades
% ---------------------------------------------------------
num_incomp_global = zeros(nReq,1);
for i = 1:nReq
    num_incomp_global(i) = sum(relation_SIPREM(i,:) == 2);
end
NumIncomp_ord = num_incomp_global(ord_rank);

FlagGlobal = strings(nReq,1);
for k = 1:nReq
    if NumIncomp_ord(k) <= 2
        FlagGlobal(k) = "Baixa";
    elseif NumIncomp_ord(k) <= 5
        FlagGlobal(k) = "Média";
    else
        FlagGlobal(k) = "Alta";
    end
end

% ---------------------------------------------------------
% REGRA 1: incomparabilidade com vizinho imediato
% ---------------------------------------------------------
Inc_Acima_1  = strings(nReq,1);
Inc_Abaixo_1 = strings(nReq,1);

for k = 1:nReq
    i = ord_rank(k);

    if k == 1
        Inc_Acima_1(k) = "-";
    else
        j_up = ord_rank(k-1);
        if relation_SIPREM(i,j_up) == 2
            Inc_Acima_1(k) = "Sim";
        else
            Inc_Acima_1(k) = "Não";
        end
    end

    if k == nReq
        Inc_Abaixo_1(k) = "-";
    else
        j_down = ord_rank(k+1);
        if relation_SIPREM(i,j_down) == 2
            Inc_Abaixo_1(k) = "Sim";
        else
            Inc_Abaixo_1(k) = "Não";
        end
    end
end

% ---------------------------------------------------------
% REGRA 3: checagem ampliada (até 3 posições acima/abaixo)
% ---------------------------------------------------------
Inc_Acima_3  = strings(nReq,1);
Inc_Abaixo_3 = strings(nReq,1);
Qtd_Acima_3  = zeros(nReq,1);
Qtd_Abaixo_3 = zeros(nReq,1);

for k = 1:nReq
    i = ord_rank(k);

    % acima (ate 3 posicoes)
    idx_up = max(1, k-3):(k-1);
    if isempty(idx_up)
        Inc_Acima_3(k) = "-";
    else
        count_up = 0;
        for t = idx_up
            j = ord_rank(t);
            if relation_SIPREM(i,j) == 2
                count_up = count_up + 1;
            end
        end
        Qtd_Acima_3(k) = count_up;
        if count_up > 0
            Inc_Acima_3(k) = "Sim";
        else
            Inc_Acima_3(k) = "Não";
        end
    end

    % abaixo (ate 3 posicoes)
    idx_down = (k+1):min(nReq, k+3);
    if isempty(idx_down)
        Inc_Abaixo_3(k) = "-";
    else
        count_down = 0;
        for t = idx_down
            j = ord_rank(t);
            if relation_SIPREM(i,j) == 2
                count_down = count_down + 1;
            end
        end
        Qtd_Abaixo_3(k) = count_down;
        if count_down > 0
            Inc_Abaixo_3(k) = "Sim";
        else
            Inc_Abaixo_3(k) = "Não";
        end
    end
end

% ---------------------------------------------------------
% LEITURA FINAL
% prioridade da leitura:
% 1. fronteira critica
% 2. zona cinzenta
% 3. atencao local
% 4. alerta estrutural
% 5. robusto
% ---------------------------------------------------------
Leitura = strings(nReq,1);

for k = 1:nReq

    mudou_grupo_acima  = false;
    mudou_grupo_abaixo = false;

    if k > 1
        mudou_grupo_acima = Grupo_ord(k) ~= Grupo_ord(k-1);
    end
    if k < nReq
        mudou_grupo_abaixo = Grupo_ord(k) ~= Grupo_ord(k+1);
    end

    inc_local_acima  = (Inc_Acima_1(k)  == "Sim");
    inc_local_abaixo = (Inc_Abaixo_1(k) == "Sim");

    inc_amp_acima  = (Inc_Acima_3(k)  == "Sim");
    inc_amp_abaixo = (Inc_Abaixo_3(k) == "Sim");

    if (inc_local_acima && mudou_grupo_acima) || (inc_local_abaixo && mudou_grupo_abaixo)
        Leitura(k) = "Fronteira crítica";

    elseif inc_local_acima && inc_local_abaixo
        Leitura(k) = "Zona cinzenta";

    elseif inc_local_acima || inc_local_abaixo
        Leitura(k) = "Atenção local";

    elseif (inc_amp_acima || inc_amp_abaixo) && NumIncomp_ord(k) > 2
        Leitura(k) = "Alerta estrutural";

    else
        Leitura(k) = "Robusto";
    end
end

% ---------------------------------------------------------
% TABELA FINAL
% ---------------------------------------------------------
T_local = table(Req_ord(:), ID_ord(:), Rank_ord(:), Phi_ord(:), Grupo_ord(:), ...
    Inc_Acima_1(:), Inc_Abaixo_1(:), ...
    Inc_Acima_3(:), Inc_Abaixo_3(:), ...
    Qtd_Acima_3(:), Qtd_Abaixo_3(:), ...
    NumIncomp_ord(:), FlagGlobal(:), Leitura(:), ...
    'VariableNames', {'Req','ID','Rank_FPII','PhiNet','Grupo_KMeans', ...
                      'Inc_Acima_1','Inc_Abaixo_1', ...
                      'Inc_Acima_3','Inc_Abaixo_3', ...
                      'Qtd_Acima_3','Qtd_Abaixo_3', ...
                      'NumIncomp_Global','FlagGlobal','Leitura'});

% disp(' ')
% disp('--- TABELA FINAL: RANK + GRUPO + INCOMPARABILIDADE LOCAL ---')
% disp(T_local)

writetable(T_local, 'Tabela_Final_Rank_Grupo_Incomp_Local.xlsx');

%% =========================================================
% EXPORTA RESULTADOS PARA COMPARAÇÃO
%% =========================================================

ResultadosExpress.PhiNet    = phi_net;
ResultadosExpress.Rank      = rank_SIPREM;
ResultadosExpress.Categoria = cat;
ResultadosExpress.ID        = IDs;
ResultadosExpress.Req       = req_labels;
ResultadosExpress.Pesos     = w_group_defuzz;

save('Resultados_Express.mat','ResultadosExpress');

disp(' ')
disp('Resultados Express exportados.')



%% =========================================================
% EXPORTAÇÃO AUTOMÁTICA DE TODAS AS FIGURAS EM FORMATO VETORIAL
%% =========================================================

figuras_abertas = findall(groot,'Type','figure');

% Ordena pelo número de criação da figura
[~,ord_fig] = sort([figuras_abertas.Number]);
figuras_abertas = figuras_abertas(ord_fig);

nomes_ja_utilizados = strings(0,1);

fprintf('\n');
fprintf('============================================================\n');
fprintf('EXPORTAÇÃO DAS FIGURAS VETORIAIS\n');
fprintf('============================================================\n');

for f = 1:numel(figuras_abertas)

    fig_atual = figuras_abertas(f);

    % Obtém o título principal da figura
    titulo_figura = obterTituloFigura(fig_atual);

    % Caso não exista título
    if strlength(strtrim(titulo_figura)) == 0
        titulo_figura = sprintf('Figura_%02d',f);
    end

    % Converte o título em um nome de arquivo seguro
    nome_base = sanitizarNomeArquivo(titulo_figura);

    % Evita arquivos com nomes repetidos
    nome_final = nome_base;
    contador_repeticao = 2;

    while any(strcmpi(nomes_ja_utilizados,nome_final))

        nome_final = sprintf( ...
            '%s_%02d', ...
            nome_base, ...
            contador_repeticao);

        contador_repeticao = contador_repeticao+1;

    end

    nomes_ja_utilizados(end+1,1) = string(nome_final);

    arquivo = fullfile( ...
    pasta_figuras, ...
    [nome_final '.pdf']);

exportgraphics( ...
    fig_atual, ...
    arquivo, ...
    'ContentType','vector', ...
    'BackgroundColor','white');

fprintf('Salva: %s.pdf\n',nome_final);
end

fprintf('\n%d figuras vetoriais foram salvas em:\n', ...
    numel(figuras_abertas));

fprintf('%s\n',pasta_figuras);

%% ---------------------------------------------------------
% MANTÉM SOMENTE AS TRÊS FIGURAS PRINCIPAIS ABERTAS
%% ---------------------------------------------------------

figuras_manter = [ ...
    fig_posicoes_pgs(:); ...
    fig_footrule; ...
    fig_classificacoes_pgs(:)];

for f = 1:numel(figuras_abertas)

    if ~any(figuras_abertas(f) == figuras_manter)
        close(figuras_abertas(f));
    end

end

% Restaura o padrão do MATLAB para execuções posteriores
set(groot,'defaultFigureVisible','on');

fprintf('\nFiguras mantidas abertas no MATLAB (%d requisitos por página):\n', req_por_pagina);
fprintf('1. Heatmap das posições no ranking (%d pág.)\n', numel(fig_posicoes_pgs));
fprintf('2. Spearman Footrule normalizada\n');
fprintf('3. Heatmap das classificações (%d pág.)\n', numel(fig_classificacoes_pgs));
%% =========================================================
% FUNÇÕES AUXILIARES
%% =========================================================
function pags = paginarRequisitos(nReq, porPagina)
% Divide 1:nReq em blocos de no máximo porPagina requisitos.
    nPag = ceil(nReq/porPagina);
    pags = cell(nPag,1);
    for p = 1:nPag
        pags{p} = ((p-1)*porPagina+1):min(p*porPagina,nReq);
    end
end

function titulo = obterTituloFigura(fig)
% =========================================================
% Obtém o título principal de uma figura MATLAB.
%
% Prioridade:
%   1. sgtitle
%   2. título de um eixo
%   3. propriedade Name da figura
% =========================================================

titulo = "";

% Tenta encontrar um sgtitle
objetos_texto = findall(fig,'Type','Text');

for i = 1:numel(objetos_texto)

    try

        texto = string(objetos_texto(i).String);

        if strlength(strtrim(texto)) > 0

            % sgtitle normalmente possui Tag = 'suptitle'
            if strcmpi(objetos_texto(i).Tag,'suptitle')
                titulo = strjoin(texto," ");
                return;
            end

        end

    catch
    end

end

% Procura títulos dos eixos
eixos = findall(fig,'Type','axes');

for i = 1:numel(eixos)

    try

        texto_titulo = string(eixos(i).Title.String);

        if ~isempty(texto_titulo) && ...
                any(strlength(strtrim(texto_titulo)) > 0)

            titulo = strjoin(texto_titulo," ");
            return;

        end

    catch
    end

end

% Usa o nome da janela como alternativa
if isgraphics(fig,'figure')
    try
        nome_figura = string(fig.Name);

        if strlength(strtrim(nome_figura)) > 0
            titulo = nome_figura;
        end

    catch
        % Handle inválido ou figura já deletada:
        % mantém titulo vazio.
    end
end

end

function nome_seguro = sanitizarNomeArquivo(titulo)
% =========================================================
% Transforma o título da figura em um nome válido de arquivo.
% =========================================================

nome_seguro = char(string(titulo));

% Remove comandos simples de LaTeX
nome_seguro = regexprep(nome_seguro,'\\[a-zA-Z]+','');

% Substitui caracteres inválidos em nomes de arquivo
nome_seguro = regexprep( ...
    nome_seguro, ...
    '[<>:"/\\|?*]', ...
    '');

% Substitui espaços e pontuação por underline
nome_seguro = regexprep( ...
    nome_seguro, ...
    '[^\wÀ-ÿ-]+', ...
    '_');

% Remove repetições de underscore
nome_seguro = regexprep(nome_seguro,'_+','_');

% Remove underscores no início e no fim
nome_seguro = regexprep(nome_seguro,'^_|_$','');

% Limita o tamanho do nome
max_caracteres = 120;

if length(nome_seguro) > max_caracteres
    nome_seguro = nome_seguro(1:max_caracteres);
end

if isempty(nome_seguro)
    nome_seguro = 'Figura_sem_titulo';
end

end


function kappa = weightedCohenKappa(x, y, nClasses, tipoPeso)
% =========================================================
% WEIGHTEDCOHENKAPPA
%
% Calcula o Weighted Cohen's Kappa para duas classificações
% ordinais.
%
% Entradas:
%   x          = classificações do avaliador A
%   y          = classificações do avaliador B
%   nClasses   = número de categorias
%   tipoPeso   = 'linear' ou 'quadratic'
%
% Saída:
%   kappa      = coeficiente Kappa ponderado
%
% Para o SIPREM:
%   1 = Key
%   2 = G1
%   3 = G2
%   4 = G3
% =========================================================

    % Garante vetores-coluna
    x = x(:);
    y = y(:);

    % Remove registros inválidos ou ausentes
    validos = ...
        ~isnan(x) & ...
        ~isnan(y) & ...
        x >= 1 & x <= nClasses & ...
        y >= 1 & y <= nClasses;

    x = x(validos);
    y = y(validos);

    n = numel(x);

    if n == 0
        kappa = NaN;
        return;
    end

    %% -----------------------------------------------------
    % Matriz de contingência observada
    %% -----------------------------------------------------

    O = zeros(nClasses,nClasses);

    for r = 1:n

        classe_x = x(r);
        classe_y = y(r);

        O(classe_x,classe_y) = ...
            O(classe_x,classe_y) + 1;

    end

    % Converte contagens em proporções
    O = O/n;

    %% -----------------------------------------------------
    % Distribuições marginais
    %% -----------------------------------------------------

    marginal_x = sum(O,2);
    marginal_y = sum(O,1);

    % Concordância esperada pelo acaso
    E = marginal_x*marginal_y;

    %% -----------------------------------------------------
    % Matriz de pesos de concordância
    %% -----------------------------------------------------

    W = zeros(nClasses,nClasses);

    for i = 1:nClasses

        for j = 1:nClasses

            distancia = abs(i-j)/(nClasses-1);

            switch lower(tipoPeso)

                case 'linear'

                    W(i,j) = 1-distancia;

                case {'quadratic','quadratico','quadrática'}

                    W(i,j) = 1-distancia^2;

                otherwise

                    error([ ...
                        'Tipo de peso inválido. ', ...
                        'Use ''linear'' ou ''quadratic''.']);

            end

        end
    end

    %% -----------------------------------------------------
    % Concordâncias ponderadas
    %% -----------------------------------------------------

    concordancia_observada = sum(W.*O,'all');
    concordancia_esperada  = sum(W.*E,'all');

    denominador = 1-concordancia_esperada;

    if abs(denominador) < eps

        % Ocorre, por exemplo, quando ambas as fontes atribuem
        % exatamente uma única categoria a todos os requisitos.
        if abs(concordancia_observada-1) < 1e-12
            kappa = 1;
        else
            kappa = NaN;
        end

    else

        kappa = ...
            (concordancia_observada-concordancia_esperada) / ...
            denominador;

    end

    % Proteção contra pequenos erros numéricos
    kappa = max(-1,min(1,kappa));

end

function [cat, idx_km_full, C_sorted, group_names] = ...
    classify_requirements_kmeans(phi_vec, key_idx)
nReq = numel(phi_vec);

cat = strings(nReq,1);
idx_km_full = nan(nReq,1);
C_sorted = [];
group_names = strings(0,1);
    % -----------------------------------------------------
    % Classificação:
    %   - Key: requisitos previamente definidos
    %   - Demais: K-means em 3 grupos sobre phi_net
    %
    % Regra de rotulagem:
    %   maior centróide  -> Grupo 1
    %   centróide médio  -> Grupo 2
    %   menor centróide  -> Grupo 3
    % -----------------------------------------------------

    nReq = numel(phi_vec);
    cat = strings(nReq,1);

    key_idx = unique(key_idx(:));
    cat(key_idx) = "Key";

    idx_rest = setdiff((1:nReq)', key_idx);
    n_rest = numel(idx_rest);

    if isempty(idx_rest)
        return;
    end

    % Se houver poucos requisitos não-Key, evita erro do kmeans
    if n_rest == 1
        cat(idx_rest) = "Grupo 1";
        return;
    elseif n_rest == 2
        [~,ord2] = sort(phi_vec(idx_rest), 'descend');
        cat(idx_rest(ord2(1))) = "Grupo 1";
        cat(idx_rest(ord2(2))) = "Grupo 2";
        return;
    end

    % Número efetivo de clusters
    k = min(3, n_rest);

    % K-means sobre os fluxos líquidos dos não-Key
    phi_rest = phi_vec(idx_rest);

    % Replicates melhora estabilidade
    [idx_km, C] = kmeans(phi_rest, k, ...
    'Replicates', 20, ...
    'Start', 'plus', ...
    'Distance', 'sqeuclidean');

    % Ordena centróides do maior para o menor
    [~, ordC] = sort(C, 'descend');

    % Mapeia cluster -> grupo
    cluster_to_group = strings(k,1);
    if k >= 1, cluster_to_group(ordC(1)) = "Grupo 1"; end
    if k >= 2, cluster_to_group(ordC(2)) = "Grupo 2"; end
    if k >= 3, cluster_to_group(ordC(3)) = "Grupo 3"; end

    % Atribui grupos
    for i = 1:n_rest
        cat(idx_rest(i)) = cluster_to_group(idx_km(i));
    end
end

function code = classToCode(cat_vec)
    code = zeros(numel(cat_vec),1);

    for i = 1:numel(cat_vec)
        switch string(cat_vec(i))
            case "Key"
                code(i) = 1;
            case "Grupo 1"
                code(i) = 2;
            case "Grupo 2"
                code(i) = 3;
            case "Grupo 3"
                code(i) = 4;
            otherwise
                code(i) = NaN;
        end
    end
end
function trap = crispSaatyToTrap(val)

    % Escala trapezoidal adotada
    scale = [
        1 1.0 1.0 1.0 1.0;
        2 1.0 1.5 2.5 3.0;
        3 2.0 2.5 3.5 4.0;
        4 3.0 3.5 4.5 5.0;
        5 4.0 4.5 5.5 6.0;
        6 5.0 5.5 6.5 7.0;
        7 6.0 6.5 7.5 8.0;
        8 7.0 7.5 8.5 9.0;
        9 8.0 8.5 9.0 9.0
    ];

    if ~isscalar(val) || ~isfinite(val) || val <= 0
        error('Valor Saaty deve ser positivo e finito.');
    end

    % Igualdade
    if abs(val - 1) < 1e-12
        trap = [1 1 1 1];
        return;
    end

    % ---------------------------------------------------------
    % Valores recíprocos
    %
    % Não interpolar diretamente x < 1.
    % Fuzzifica 1/x e toma o inverso fuzzy exato.
    % ---------------------------------------------------------
    if val < 1

        directTrap = crispSaatyToTrap(1/val);

        trap = [
            1/directTrap(4), ...
            1/directTrap(3), ...
            1/directTrap(2), ...
            1/directTrap(1)
        ];

        return;
    end

    % Limite superior da escala
    if val > 9
        error('Valor da escala Saaty acima de 9: %.6f', val);
    end

    % Valor exatamente presente na escala
    if abs(val - round(val)) < 1e-12

        k = round(val);
        trap = scale(k,2:5);
        return;
    end

    % ---------------------------------------------------------
    % Interpolação linear para valores intermediários > 1
    % ---------------------------------------------------------
    lower = floor(val);
    upper = ceil(val);

    lambda = ...
        (val - lower) / ...
        (upper - lower);

    trap = ...
        (1-lambda)*scale(lower,2:5) + ...
        lambda*scale(upper,2:5);

end

function w = fahpBuckleyTrap(A_group)
    n = size(A_group, 1);
    r = zeros(n, 4);

    for i = 1:n
        prod_trap = [1, 1, 1, 1];
        for j = 1:n
            t = squeeze(A_group(i,j,:))';
            prod_trap = prod_trap .* t;
        end
        r(i,:) = prod_trap .^ (1/n);
    end

    sum_r = [0, 0, 0, 0];
    for i = 1:n
        sum_r = trap_add(sum_r, r(i,:));
    end

    inv_sum_r = trap_inv(sum_r);

    w = zeros(n, 4);
    for i = 1:n
        w(i,:) = trap_mul_positive(r(i,:), inv_sum_r);
    end

    wd = zeros(n,1);
    for i = 1:n
        wd(i) = defuzz_coa(w(i,:));
    end
    wd = wd / sum(wd);

    for i = 1:n
        factor = wd(i) / max(defuzz_coa(w(i,:)), eps);
        w(i,:) = w(i,:) * factor;
    end
end

function out = pref_trap(D, type, q, p)
    out = [ ...
        pref_scalar(D(1), type, q, p), ...
        pref_scalar(D(2), type, q, p), ...
        pref_scalar(D(3), type, q, p), ...
        pref_scalar(D(4), type, q, p)];
    out = sort(out);
end

function p_res = pref_scalar(d, type, q, p)

    % Garantir que d >= 0 (PROMETHEE padrão)
    d = max(0, d);

    switch type

        % =========================
        % Tipo 1: Usual
        % =========================
        case 1
            p_res = double(d > 0);

        % =========================
        % Tipo 2: U-shape
        % =========================
        case 2
            if d <= q
                p_res = 0;
            else
                p_res = 1;
            end

        % =========================
        % Tipo 3: V-shape
        % =========================
        case 3
            if d <= 0
                p_res = 0;
            elseif d <= p
                p_res = d / p;
            else
                p_res = 1;
            end

        % =========================
        % Tipo 4: Level (como você tinha)
        % =========================
        case 4
            if d <= q
                p_res = 0;
            elseif d <= p
                p_res = 0.5;
            else
                p_res = 1;
            end

        % =========================
        % Tipo 5: Linear (V-shape com indiferença)
        % =========================
        case 5
            if d <= q
                p_res = 0;
            elseif d <= p
                p_res = (d - q) / (p - q);
            else
                p_res = 1;
            end

        % =========================
        % Tipo 6: Gaussian
        % =========================
        case 6
            if d <= 0
                p_res = 0;
            else
                sigma = p / 3; % regra comum
                p_res = 1 - exp(-(d^2) / (2 * sigma^2));
            end

        otherwise
            error('Tipo de preferência não implementado.');

    end
end
function C = trap_add(A, B)
    C = [A(1)+B(1), A(2)+B(2), A(3)+B(3), A(4)+B(4)];
end

function C = trap_sub(A, B)
    C = [A(1)-B(4), A(2)-B(3), A(3)-B(2), A(4)-B(1)];
end

function C = trap_scalar_div(A, s)
    C = A / s;
end

function invA = trap_inv(A)
    if any(A <= 0)
        error('trap_inv requer trapézio estritamente positivo.');
    end
    invA = [1/A(4), 1/A(3), 1/A(2), 1/A(1)];
end

function C = trap_mul_positive(A, B)
    C = [A(1)*B(1), A(2)*B(2), A(3)*B(3), A(4)*B(4)];
end

function C = trap_mul_geldermann(A, B)
    ml1 = A(2); mu1 = A(3); alpha1 = A(2)-A(1); beta1 = A(4)-A(3);
    ml2 = B(2); mu2 = B(3); alpha2 = B(2)-B(1); beta2 = B(4)-B(3);

    ml = ml1 * ml2;
    mu = mu1 * mu2;
    alpha = ml1 * alpha2 + ml2 * alpha1 - alpha1 * alpha2;
    beta  = mu1 * beta2  + mu2 * beta1  + beta1 * beta2;

    alpha = max(alpha, 0);
    beta  = max(beta, 0);

    C = [ml - alpha, ml, mu, mu + beta];
    C(C < 0) = 0;
    C = sort(C);
end

function x = defuzz_coa(T)
    a = T(1); b = T(2); c = T(3); d = T(4);

    if abs(d - a) < 1e-12
        x = b;
        return;
    end

    den = 3 * (c + d - a - b);
    if abs(den) < 1e-12
        x = mean(T);
        return;
    end

    x = ((c+d)^2 - c*d - (a+b)^2 + a*b) / den;
end

function [Phi_plus, Phi_minus, phi_net, Phi_plus_fuzzy, Phi_minus_fuzzy, Phi_net_fuzzy] = ...
    runFuzzyPrometheeTrap(F, w_fuzzy, critDir, pref_types, q_vals, p_vals)

    nReq = size(F, 1);
    nCrit = size(F, 2);

    PI = zeros(nReq, nReq, 4);

    for i = 1:nReq
        for j = 1:nReq
            if i == j
                continue;
            end

            pi_ij = [0, 0, 0, 0];

            for k = 1:nCrit
                Ai = squeeze(F(i,k,:))';
                Bj = squeeze(F(j,k,:))';

                if critDir(k) == 1
                    D = trap_sub(Ai, Bj);
                else
                    D = trap_sub(Bj, Ai);
                end

                Pk = pref_trap(D, pref_types(k), q_vals(k), p_vals(k));
                Wk = squeeze(w_fuzzy(k,:))';

                term = trap_mul_geldermann(Wk, Pk);
                pi_ij = trap_add(pi_ij, term);
            end

            PI(i,j,:) = pi_ij;
        end
    end

    Phi_plus_fuzzy  = zeros(nReq, 4);
    Phi_minus_fuzzy = zeros(nReq, 4);
    Phi_net_fuzzy   = zeros(nReq, 4);

    Phi_plus  = zeros(nReq, 1);
    Phi_minus = zeros(nReq, 1);
    phi_net   = zeros(nReq, 1);

    for i = 1:nReq
        sumP = [0, 0, 0, 0];
        sumM = [0, 0, 0, 0];

        for j = 1:nReq
            if i == j
                continue;
            end
            sumP = trap_add(sumP, squeeze(PI(i,j,:))');
            sumM = trap_add(sumM, squeeze(PI(j,i,:))');
        end

        avgP = trap_scalar_div(sumP, (nReq - 1));
        avgM = trap_scalar_div(sumM, (nReq - 1));
        netF = trap_sub(avgP, avgM);

        Phi_plus_fuzzy(i,:)  = avgP;
        Phi_minus_fuzzy(i,:) = avgM;
        Phi_net_fuzzy(i,:)   = netF;

        Phi_plus(i)  = defuzz_coa(avgP);
        Phi_minus(i) = defuzz_coa(avgM);
        phi_net(i)   = defuzz_coa(netF);
    end
end
function Phi_uni = computeUnicriterionNetFlows(F, w_ref, critDir, pref_types, q_vals, p_vals)
    % Calcula os fluxos líquidos unicritério usados no GAIA-PROMETHEE
    %
    % Entradas:
    %   F         : matriz fuzzy das alternativas [nReq x nCrit x 4]
    %   w_ref     : pesos de referência (não entram no fluxo unicritério,
    %               mas mantidos por compatibilidade futura)
    %   critDir   : direção dos critérios
    %   pref_types: tipo de função de preferência
    %   q_vals    : limiares de indiferença
    %   p_vals    : limiares de preferência
    %
    % Saída:
    %   Phi_uni   : matriz [nReq x nCrit] de fluxos líquidos unicritério

    nReq  = size(F,1);
    nCrit = size(F,2);

    Phi_uni = zeros(nReq, nCrit);

    for k = 1:nCrit
        PI_k = zeros(nReq, nReq, 4);

        for i = 1:nReq
            for j = 1:nReq
                if i == j
                    continue;
                end

                Ai = squeeze(F(i,k,:))';
                Bj = squeeze(F(j,k,:))';

                if critDir(k) == 1
                    D = trap_sub(Ai, Bj);
                else
                    D = trap_sub(Bj, Ai);
                end

                Pk = pref_trap(D, pref_types(k), q_vals(k), p_vals(k));
                PI_k(i,j,:) = Pk;   % sem peso: fluxo unicritério puro
            end
        end

        for i = 1:nReq
            sumP = [0 0 0 0];
            sumM = [0 0 0 0];

            for j = 1:nReq
                if i == j
                    continue;
                end
                sumP = trap_add(sumP, squeeze(PI_k(i,j,:))');
                sumM = trap_add(sumM, squeeze(PI_k(j,i,:))');
            end

            avgP = trap_scalar_div(sumP, (nReq - 1));
            avgM = trap_scalar_div(sumM, (nReq - 1));
            netF = trap_sub(avgP, avgM);

            Phi_uni(i,k) = defuzz_coa(netF);
        end
    end
end



function trap = fuzzifyByScale(val, scale_max, TFN_eval_5, TFN_eval_7, TFN_eval_9)

    % arredonda para o valor mais próximo da escala
    v = round(val);

    % satura dentro dos limites válidos
    v = max(1, min(scale_max, v));

    switch scale_max
        case 5
            trap = TFN_eval_5(v,:);

        case 7
            trap = TFN_eval_7(v,:);

        case 9
            trap = TFN_eval_9(v,:);

        otherwise
            error('Escala não suportada.');
    end
end

function val = linguistic2num(x)

    % 1. Se vazio ou missing → erro claro
    if isempty(x) || (isstring(x) && ismissing(x))
        error('Valor vazio ou missing encontrado na planilha');
    end

    % 2. Se for numérico
    if isnumeric(x)
        if isnan(x)
            error('Valor NaN encontrado na planilha');
        end
        val = x;
        return;
    end

    % 3. Converter para string limpa
    str = lower(strtrim(string(x)));

    % Se virou missing depois da conversão
    if ismissing(str)
        error('Valor inválido (missing) encontrado');
    end

    str = char(str);

    % 4. Mapear
    if strcmp(str, 'muito alto')
        val = 7;
    elseif strcmp(str, 'alto')
        val = 6;
    elseif strcmp(str, 'moderadamente alto')
        val = 5;
    elseif strcmp(str, 'médio') || strcmp(str, 'medio')
        val = 4;
    elseif strcmp(str, 'moderadamente baixo')
        val = 3;
    elseif strcmp(str, 'baixo')
        val = 2;
    elseif strcmp(str, 'muito baixo')
        val = 1;
    else
        error('Valor linguístico desconhecido: %s', str)
    end

end

